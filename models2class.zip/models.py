import torch
import torch.nn as nn
import torch.nn.functional as F

class EEGBinaryModel(nn.Module):
    """EEG二分类模型 - 支持Hydra实例化"""
    
    def __init__(self, n_channels=17, n_timepoints=250, d_model=128, n_classes=2, dropout=0.1):
        super().__init__()
        
        # CNN编码器
        self.encoder = nn.Sequential(
            nn.Conv1d(n_channels, 64, kernel_size=7, padding=3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
            
            nn.Conv1d(64, 128, kernel_size=5, padding=2),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(2),
            
            nn.Conv1d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(16),
            
            nn.Flatten(),
            nn.Linear(256 * 16, d_model),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(d_model, d_model * 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 2, n_classes)
        )
        
        # 🔥 添加主项目需要的属性
        self.stratified = []  # extract_fea.py 第127行需要这个
        
    def forward(self, x):
        if x.dim() == 4:
            x = x.squeeze(1)
        features = self.encoder(x)
        return features  # 🔥 注意：特征提取阶段只返回特征
    
    def predict(self, x):
        """预测阶段使用"""
        features = self.forward(x)
        logits = self.classifier(features)
        return logits

class EEGNet(nn.Module):
    """EEGNet架构 - 专门为EEG设计"""
    def __init__(self, n_channels=17, n_timepoints=250, n_classes=2, dropout=0.25):
        super().__init__()
        
        # 🔥 EEGNet Block 1
        self.block1 = nn.Sequential(
            nn.Conv2d(1, 16, (1, 64), padding=(0, 32), bias=False),
            nn.BatchNorm2d(16),
            # Depthwise convolution
            nn.Conv2d(16, 32, (n_channels, 1), groups=16, bias=False),
            nn.BatchNorm2d(32),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropout)
        )
        
        # 🔥 EEGNet Block 2
        self.block2 = nn.Sequential(
            # Separable convolution
            nn.Conv2d(32, 32, (1, 16), padding=(0, 8), groups=32, bias=False),
            nn.Conv2d(32, 16, 1, bias=False),
            nn.BatchNorm2d(16),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropout)
        )
        
        # 计算特征维度
        self.feature_dim = self._get_feature_dim(n_channels, n_timepoints)
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(self.feature_dim, 64),
            nn.ELU(),
            nn.Dropout(dropout),
            nn.Linear(64, n_classes)
        )
        
        self.stratified = []
        
    def _get_feature_dim(self, n_channels, n_timepoints):
        """计算特征维度"""
        x = torch.randn(1, 1, n_channels, n_timepoints)
        x = self.block1(x)
        x = self.block2(x)
        return x.numel()
    
    def forward(self, x):
        # 确保输入是4D: (batch, 1, channels, timepoints)
        if x.dim() == 3:
            x = x.unsqueeze(1)
        
        x = self.block1(x)
        x = self.block2(x)
        features = x.view(x.size(0), -1)
        return features
    
    def predict(self, x):
        features = self.forward(x)
        logits = self.classifier(features)
        return logits

class AttentionEEGNet(nn.Module):
    """带注意力机制的EEG网络"""
    def __init__(self, n_channels=17, n_timepoints=250, n_classes=2, dropout=0.25):
        super().__init__()
        
        # 空间注意力
        self.spatial_attention = nn.Sequential(
            nn.Conv1d(n_channels, n_channels // 4, 1),
            nn.ReLU(),
            nn.Conv1d(n_channels // 4, n_channels, 1),
            nn.Sigmoid()
        )
        
        # 时间卷积
        self.temporal_conv = nn.Sequential(
            nn.Conv1d(n_channels, 64, 25, padding=12),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
            
            nn.Conv1d(64, 128, 15, padding=7),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(2),
            
            nn.Conv1d(128, 256, 10, padding=4),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(16)
        )
        
        # 时间注意力
        self.temporal_attention = nn.Sequential(
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Linear(64, 256),
            nn.Sigmoid()
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256 * 16, 512),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, n_classes)
        )
        
        self.stratified = []
    
    def forward(self, x):
        # 空间注意力
        spatial_weights = self.spatial_attention(x.mean(dim=-1, keepdim=True)).squeeze(-1)
        x = x * spatial_weights.unsqueeze(-1)
        
        # 时间卷积
        x = self.temporal_conv(x)
        
        # 时间注意力
        temporal_weights = self.temporal_attention(x.mean(dim=-1))
        x = x * temporal_weights.unsqueeze(-1)
        
        features = x.view(x.size(0), -1)
        return features
    
    def predict(self, x):
        features = self.forward(x)
        logits = self.classifier(features)
        return logits

class ImprovedEEGNet(nn.Module):
    """基于主项目优化的EEG网络 - 多尺度 + 注意力"""
    def __init__(self, n_channels=17, n_timepoints=250, n_classes=2, dropout=0.25):
        super().__init__()
        
        # 🔥 参数设置 - 针对250Hz采样率优化
        n_timeFilters = 16
        timeFilterLen = 32  # 时间卷积核
        n_msFilters = 4     # 多尺度滤波器数量
        msFilter_timeLen = 3
        
        # 🔥 膨胀卷积参数 - 适配250Hz
        dilation_array = [1, 3, 6, 12]  # 多时间尺度
        seg_att = 15        # 注意力窗口
        avgPoolLen = 8      # 平均池化
        timeSmootherLen = 3
        multiFact = 2
        
        self.n_channels = n_channels
        self.dilation_array = dilation_array
        self.msFilter_timeLen = msFilter_timeLen
        self.seg_att = seg_att
        
        # 🔥 第一层：时间卷积 + 空间-时间多尺度卷积
        self.timeConv = nn.Conv2d(1, n_timeFilters, (1, timeFilterLen), 
                                 padding=(0, (timeFilterLen-1)//2))
        
        # 🔥 多尺度空间-时间卷积（不同膨胀率）
        self.msConv1 = nn.Conv2d(n_timeFilters, n_timeFilters*n_msFilters, 
                                (n_channels, msFilter_timeLen), groups=n_timeFilters)
        self.msConv2 = nn.Conv2d(n_timeFilters, n_timeFilters*n_msFilters, 
                                (n_channels, msFilter_timeLen), 
                                dilation=(1, dilation_array[1]), groups=n_timeFilters)
        self.msConv3 = nn.Conv2d(n_timeFilters, n_timeFilters*n_msFilters, 
                                (n_channels, msFilter_timeLen), 
                                dilation=(1, dilation_array[2]), groups=n_timeFilters)
        self.msConv4 = nn.Conv2d(n_timeFilters, n_timeFilters*n_msFilters, 
                                (n_channels, msFilter_timeLen), 
                                dilation=(1, dilation_array[3]), groups=n_timeFilters)
        
        n_msFilters_total = n_timeFilters * n_msFilters * 4
        
        # 🔥 注意力机制
        self.att_conv = nn.Conv2d(n_msFilters_total, n_msFilters_total, 
                                 (1, seg_att), groups=n_msFilters_total)
        self.att_pool = nn.AvgPool2d((1, seg_att), stride=1)
        self.att_pointConv = nn.Conv2d(n_msFilters_total, n_msFilters_total, (1, 1))
        
        # 🔥 特征处理
        self.avgpool = nn.AvgPool2d((1, avgPoolLen))
        
        # 🔥 深度卷积
        self.timeConv1 = nn.Conv2d(n_msFilters_total, n_msFilters_total * multiFact, 
                                  (1, timeSmootherLen), groups=n_msFilters_total)
        self.timeConv2 = nn.Conv2d(n_msFilters_total * multiFact, 
                                  n_msFilters_total * multiFact * multiFact, 
                                  (1, timeSmootherLen), 
                                  groups=n_msFilters_total * multiFact)
        
        # 🔥 计算最终特征维度
        self.feature_dim = self._get_feature_dim(n_channels, n_timepoints)
        
        # 🔥 分类器
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(self.feature_dim, 512),
            nn.ELU(),
            nn.Dropout(dropout),
            nn.Linear(512, 128),
            nn.ELU(),
            nn.Dropout(dropout),
            nn.Linear(128, n_classes)
        )
        
        self.stratified = []
        
    def _get_feature_dim(self, n_channels, n_timepoints):
        """计算特征维度"""
        x = torch.randn(1, 1, n_channels, n_timepoints)
        with torch.no_grad():
            x = self._extract_features(x)
        return x.numel()
    
    def _extract_features(self, x):
        """特征提取核心逻辑"""
        # 时间卷积
        out = self.timeConv(x)
        
        # 🔥 多尺度空间-时间卷积
        p = [d * (self.msFilter_timeLen - 1) for d in self.dilation_array]
        
        out1 = self.msConv1(F.pad(out, (p[0]//2, p[0]-p[0]//2), "constant", 0))
        out2 = self.msConv2(F.pad(out, (p[1]//2, p[1]-p[1]//2), "constant", 0))
        out3 = self.msConv3(F.pad(out, (p[2]//2, p[2]-p[2]//2), "constant", 0))
        out4 = self.msConv4(F.pad(out, (p[3]//2, p[3]-p[3]//2), "constant", 0))
        
        # 拼接多尺度特征
        out = torch.cat((out1, out2, out3, out4), 1)  # (B, dims, 1, T)
        
        # 🔥 注意力机制
        att_w = F.relu(self.att_conv(F.pad(out, (self.seg_att-1, 0), "constant", 0)))
        att_w = self.att_pool(F.pad(att_w, (self.seg_att-1, 0), "constant", 0))
        att_w = self.att_pointConv(att_w)
        att_w = F.softmax(att_w, dim=1)  # 注意力权重
        
        # 应用注意力
        out = att_w * F.relu(out)
        
        # 🔥 特征处理
        out = self.avgpool(out)
        out = F.relu(self.timeConv1(out))
        out = F.relu(self.timeConv2(out))
        
        return out
    
    def forward(self, x):
        # 确保输入是4D: (batch, 1, channels, timepoints)
        if x.dim() == 3:
            x = x.unsqueeze(1)
        
        features = self._extract_features(x)
        features = features.view(features.size(0), -1)
        return features
    
    def predict(self, x):
        features = self.forward(x)
        logits = self.classifier(features)
        return logits

class AdvancedEEGNet(nn.Module):
    """更高级的EEG网络 - 集成多种先进技术"""
    def __init__(self, n_channels=17, n_timepoints=250, n_classes=2, dropout=0.25):
        super().__init__()
        
        # 🔥 多分支架构
        self.branch1 = self._create_branch(n_channels, [1, 3, 5], 32)    # 短时特征
        self.branch2 = self._create_branch(n_channels, [7, 11, 15], 32)  # 中时特征  
        self.branch3 = self._create_branch(n_channels, [21, 31, 41], 32) # 长时特征
        
        # 🔥 跨分支注意力
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=96, num_heads=8, dropout=dropout, batch_first=True
        )
        
        # 🔥 时间注意力
        self.temporal_attention = nn.Sequential(
            nn.Conv1d(96, 24, 1),
            nn.ReLU(),
            nn.Conv1d(24, 96, 1),
            nn.Sigmoid()
        )
        
        # 🔥 特征融合
        self.feature_fusion = nn.Sequential(
            nn.Conv1d(96, 128, 1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(32),
            nn.Dropout(dropout)
        )
        
        # 🔥 分类器
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 32, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, n_classes)
        )
        
        self.stratified = []
    
    def _create_branch(self, n_channels, kernel_sizes, out_channels):
        """创建单个分支"""
        layers = []
        for i, k in enumerate(kernel_sizes):
            if i == 0:
                layers.extend([
                    nn.Conv1d(n_channels, out_channels, k, padding=k//2),
                    nn.BatchNorm1d(out_channels),
                    nn.ReLU()
                ])
            else:
                layers.extend([
                    nn.Conv1d(out_channels, out_channels, k, padding=k//2),
                    nn.BatchNorm1d(out_channels),
                    nn.ReLU()
                ])
        
        layers.append(nn.MaxPool1d(2))
        return nn.Sequential(*layers)
    
    def forward(self, x):
        if x.dim() == 4:
            x = x.squeeze(1)
        
        # 🔥 多分支特征提取
        feat1 = self.branch1(x)  # (B, 32, T/2)
        feat2 = self.branch2(x)  # (B, 32, T/2)
        feat3 = self.branch3(x)  # (B, 32, T/2)
        
        # 🔥 拼接分支特征
        combined_feat = torch.cat([feat1, feat2, feat3], dim=1)  # (B, 96, T/2)
        
        # 🔥 跨分支注意力
        # 转换为 (B, T/2, 96) 用于多头注意力
        att_input = combined_feat.transpose(1, 2)
        att_output, _ = self.cross_attention(att_input, att_input, att_input)
        att_output = att_output.transpose(1, 2)  # 转回 (B, 96, T/2)
        
        # 🔥 时间注意力
        temp_weights = self.temporal_attention(att_output)
        weighted_feat = att_output * temp_weights
        
        # 🔥 特征融合
        final_feat = self.feature_fusion(weighted_feat)
        
        return final_feat.view(final_feat.size(0), -1)
    
    def predict(self, x):
        features = self.forward(x)
        logits = self.classifier(features)
        return logits

class ResidualEEGNet(nn.Module):
    """带残差连接的EEG网络"""
    def __init__(self, n_channels=17, n_timepoints=250, n_classes=2, dropout=0.25):
        super().__init__()
        
        # 🔥 输入投影
        self.input_proj = nn.Conv1d(n_channels, 64, 1)
        
        # 🔥 残差块
        self.res_blocks = nn.ModuleList([
            self._make_res_block(64, 64, 7),
            self._make_res_block(64, 128, 5),
            self._make_res_block(128, 256, 3),
        ])
        
        # 🔥 注意力
        self.attention = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Linear(64, 256),
            nn.Sigmoid()
        )
        
        # 🔥 分类器
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool1d(16),
            nn.Flatten(),
            nn.Linear(256 * 16, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, n_classes)
        )
        
        self.stratified = []
    
    def _make_res_block(self, in_channels, out_channels, kernel_size):
        """创建残差块"""
        return nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(),
            nn.Conv1d(out_channels, out_channels, kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(out_channels),
        )
    
    def forward(self, x):
        if x.dim() == 4:
            x = x.squeeze(1)
        
        # 输入投影
        x = self.input_proj(x)
        
        # 残差块
        for i, block in enumerate(self.res_blocks):
            identity = x
            out = block(x)
            
            # 调整维度用于残差连接
            if identity.shape[1] != out.shape[1]:
                identity = F.interpolate(identity, size=out.shape[2])
                identity = nn.Conv1d(identity.shape[1], out.shape[1], 1).to(x.device)(identity)
            
            x = F.relu(out + identity)
            x = F.max_pool1d(x, 2)
        
        # 注意力
        att_weights = self.attention(x).unsqueeze(-1)
        x = x * att_weights
        
        return x.view(x.size(0), -1)
    
    def predict(self, x):
        features = self.forward(x)
        logits = self.classifier(features)
        return logits

def create_binary_model(cfg):
    """创建优化的模型"""
    model_type = getattr(cfg.model, 'model_type', 'improved_eegnet')
    
    if model_type == 'improved_eegnet':
        model = ImprovedEEGNet(
            n_channels=cfg.model.n_channels,
            n_timepoints=cfg.model.n_timepoints,
            n_classes=cfg.model.n_classes,
            dropout=cfg.model.dropout
        )
    elif model_type == 'advanced_eegnet':
        model = AdvancedEEGNet(
            n_channels=cfg.model.n_channels,
            n_timepoints=cfg.model.n_timepoints,
            n_classes=cfg.model.n_classes,
            dropout=cfg.model.dropout
        )
    elif model_type == 'residual_eegnet':
        model = ResidualEEGNet(
            n_channels=cfg.model.n_channels,
            n_timepoints=cfg.model.n_timepoints,
            n_classes=cfg.model.n_classes,
            dropout=cfg.model.dropout
        )
    elif model_type == 'eegnet':
        model = EEGNet(
            n_channels=cfg.model.n_channels,
            n_timepoints=cfg.model.n_timepoints,
            n_classes=cfg.model.n_classes,
            dropout=cfg.model.dropout
        )
    elif model_type == 'attention':
        model = AttentionEEGNet(
            n_channels=cfg.model.n_channels,
            n_timepoints=cfg.model.n_timepoints,
            n_classes=cfg.model.n_classes,
            dropout=cfg.model.dropout
        )
    else:
        # 原始模型
        model = EEGBinaryModel(
            n_channels=cfg.model.n_channels,
            n_timepoints=cfg.model.n_timepoints,
            d_model=cfg.model.d_model,
            n_classes=cfg.model.n_classes,
            dropout=cfg.model.dropout
        )
    
    return model